package Dependencias;

public class SaveCliente{


    private IPersistence persistence;

    public SaveCliente(IPersistence persistence) {
        this.persistence = persistence;
    }

    public void savePerson(Cliente cliente) {
        persistence.save(cliente);
    }

}