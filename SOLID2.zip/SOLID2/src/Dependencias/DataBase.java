package Dependencias;

public class DataBase implements IPersistence {

    public void save(Object object) {
        System.out.println("object save successfully");

    }

}
