package Dependencias;
// lo que aplica esta carpeta es la inversion de dependencias
//el caso de que se quiera utilizar cualquier base de datos en vez de una en especifico y asi evitar el acoplamiento
// crearla para que reciba una base de datos de un solo tipo por ejemplo Oracle

public interface IPersistence {
    public void save(Object object);

}

