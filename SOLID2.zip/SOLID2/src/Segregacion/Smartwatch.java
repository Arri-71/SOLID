package Segregacion;

import Segregacion.Ismart;

import java.text.SimpleDateFormat;
import java.util.Date;

public  class Smartwatch implements Ismart {

    public String getTime() {
        SimpleDateFormat format = new SimpleDateFormat("hh:mm:ss");
        System.out.println(format.format(new Date()));
        return format.format(new Date());
    }

    public String getEmailNotifications() throws Exception {
        return "You have 5 emails";
    }
}


