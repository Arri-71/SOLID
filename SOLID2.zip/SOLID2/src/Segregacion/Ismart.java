package Segregacion;

import Segregacion.Isimple;

public interface Ismart  extends Isimple {

        public String getEmailNotifications() throws Exception;
}
