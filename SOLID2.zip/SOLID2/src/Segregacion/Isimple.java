package Segregacion;
import java.util.function.IntSupplier;


//se utilizan los meotodos necesarios en cada interfaz, para evitar el acoplamiento
//aplicando el prinicipio de segregacion de dependencias
//ademas, cada cosa tiene una unica responsabilidad y se pueden agregar mas cosas, terminaria de aplicar los otros 2 principios


public interface Isimple {
   public String getTime();
}
