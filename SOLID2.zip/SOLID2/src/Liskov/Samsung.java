package Liskov;

import Liskov.Iprecio;

public class Samsung implements Iprecio {

    public double calculatePrecio(double coste, double impuesto) {

        return (coste*.6)+(impuesto*.4);

    }

}