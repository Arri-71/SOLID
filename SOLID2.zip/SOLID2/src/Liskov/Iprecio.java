package Liskov;
//aqui es aplicado el principio de sustitucion de liskov donde se aplica en el caso de un calculo del precio de un celular
//se puede usar en varios celulares
public interface Iprecio {

    public double calculatePrecio(double coste, double impuesto);

}