package Liskov;

import Liskov.Iprecio;

public class Iphone implements Iprecio {

    public double calculatePrecio(double coste, double impuesto) {

        return (coste*.8)+(impuesto*.2);

    }

}